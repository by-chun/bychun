#!/system/bin/sh
pkill -f "g-frida/frida-server" 2>/dev/null
