#!/system/bin/sh
MODDIR=${0%/*}
BIN=/data/adb/g-frida/frida-server
[ -x "$BIN" ] || exit 0
nohup "$BIN" >/dev/null 2>&1 &
