#!/system/bin/sh
mkdir -p /data/adb/g-frida
chmod 755 /data/adb/g-frida
ui_print "- 目录已就绪: /data/adb/g-frida"
ui_print "- 把 frida-server 放到该目录（AI 可代下），重启后自动启动"
