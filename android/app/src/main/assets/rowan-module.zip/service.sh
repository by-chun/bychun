#!/system/bin/sh
MODDIR=${0%/*}
BIN=/data/adb/g-frida/frida-server
[ -x "$BIN" ] || exit 0
if ! pgrep -f "g-frida/frida-server" >/dev/null 2>&1; then
  nohup "$BIN" >/dev/null 2>&1 &
fi
